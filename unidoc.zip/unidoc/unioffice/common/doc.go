// Package common contains wrapper types and utilities common to all of the
// OOXML document formats.
package common
