## Licensing Information

This software package is a commercial product and requires a license
code to operate.

The use of this software package is governed by the end-user license agreement 
(EULA) available at: https://unidoc.io/eula/

To obtain a Trial license code to evaluate the software, please visit
https://unidoc.io/
